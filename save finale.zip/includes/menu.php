
    <header>
      <!-- Fixed navbar -->
      <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
      
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
              <a class="nav-link" href="index.php">Accueil</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="voyants.php">Nos voyants</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="tarot.php">Tarot</a>
            </li>
              <li class="nav-item">
              <a class="nav-link" href="horoscope.php">Horoscope</a>
            </li>
          </ul>
          <form class="form-inline mt-2 mt-md-0">
         <b style="color:#aab4c4;">   Contactez nous au : 08.xx.xx.xx.xx </b>
          </form>
        </div>
      </nav>
    </header>